# SaveTheOteff_kotlin
Kotlin android game that lets you save the boarder area 
